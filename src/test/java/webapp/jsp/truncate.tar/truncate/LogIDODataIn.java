
package jex.adm.batch.simple.truncate;

import jex.data.impl.ido.JexDataInIDO;
import jex.data.impl.ido.JexDataOutIDO;
import jex.data.item.DataItem;
import jex.data.rule.RuleIDO;
import jex.util.StringUtil;

public class LogIDODataIn extends JexDataInIDO 
{
	private static final long serialVersionUID = -1368313867988161988L;
	public static final String KEY_EXT_TABLE = "__EXT_TBL__";
	
	private String _strSQL = null;
	private DataItem[] _idoOutItems = null;
	private RuleIDO _idoRule = null;
	
	public LogIDODataIn(String id)
	{
		super(id);
	}
	
	public void _setExtTable(String s) 
	{
		if (s ==  null)
		{
			this.removeAttribute(KEY_EXT_TABLE);
		}
		else
		{
			this.setAttribute(KEY_EXT_TABLE, s);
		}
		_strSQL = null;
	}
	
	@Override
	public String _getSQL () 
	{
		if (_strSQL == null)
		{
			String strTmp = this._getSQLImpl(_getVendor());
			String strExt = (String)getAttribute(KEY_EXT_TABLE);
			if (strExt != null)
			{
				strTmp = StringUtil.replace(strTmp, "%TABLE%", strExt);
			}
			else
			{
				strTmp =  StringUtil.replace(strTmp, "%TABLE%", "");
			}
			_strSQL = strTmp; 
		}
		return _strSQL;
	}
	
	protected String _getSQLImpl(String vender)
	{
		return _getRule().getSQL(vender);
	}

	protected void  _setOutDataItems(DataItem[] dataItems)
	{
		_idoOutItems = dataItems;
	}
	
	protected DataItem[]  _getOutDataItems()
	{
		return _idoOutItems;
	}	
	
//	protected DataItem[] _getDataItems()
//	{
//		if (_idoItems == null)
//		{
//			_idoItems = _getRule().getInputDataItems();
//		}
//		return _idoItems;
//	}

	@Override
	public RuleIDO _getRule()
	{
		return _idoRule;
	}
	
	protected void _setRule(RuleIDO idoRule)
	{
		_idoRule = idoRule;
		if (_idoRule != null)
		{
			this._setTarget(_idoRule.getTarget());
		}
	}
	
	@Override
	public JexDataOutIDO createReverseDataImpl()
	{
		LogIDODataOut result = new LogIDODataOut(this._getId(), _getOutDataItems());
		result._setRule(this._getRule());
		return result;
	}
}

