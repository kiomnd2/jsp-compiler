package jex.adm.batch.simple.truncate;

import java.util.ArrayList;
import java.util.List;

import jex.data.JexData;
import jex.data.JexDataList;
import jex.data.JexDataMap;
import jex.data.impl.JexDataRecordList;
import jex.data.impl.ido.JexDataInIDO;
import jex.data.loader.JexDataCreator;
import jex.exception.JexBIZException;
import jex.exception.JexException;
import jex.resource.cci.JexConnection;
import jex.resource.cci.JexConnectionManager;
import jex.simplebatch.AbstractSimpleBatchTask;
import jex.sys.info.impl.IDOInfo;
import jex.util.StringUtil;
import jex.util.date.DateTime;

/**
 * Jex 로그 삭제배치
 *
 ** 
 * @author kiomnd2
 *
 */
public class LogTruncate extends AbstractSimpleBatchTask {

    private String curDate;
    private String[] idoList = { "JEX_AD_TRNC_T01", "JEX_AD_TRNC_T02", "JEX_AD_TRNC_T03" };

    @Override
    public JexData execute(JexData input) throws JexException, JexBIZException, Throwable {

        JexData result = input.createReverseData();

        JexDataList<JexData> list = new JexDataRecordList();
        this.curDate = DateTime.getInstance().getDate("YYYYMMDD0W");

        String tableExt = input.get("TABLE_EXT").toString();
        if (StringUtil.isBlank(tableExt)) 
        {
            throw new JexBIZException("TABLE_EXT는 필수값 잆니다.");
        }

        List<String> calc = null;
        // DD일 때,
        if ("DD".equalsIgnoreCase(tableExt)) 
        {
            calc = calcTrnc(input, 6, 8, 31);
        } 
        else if ("MM".equalsIgnoreCase(tableExt)) 
        {
            calc = calcTrnc(input, 4, 6, 12);
        } 
        else if ("OW".equalsIgnoreCase(tableExt)) // 주별로 최대 5주
        {
            calc = calcTrnc(input, 8, 10, 6);
        }
        
        for (int i = 0; i < calc.size(); i++) 
        {
            String c = calc.get(i);
            try {
                executeIdo(c);
                this.incrementSuccessCount();
            } catch (JexException e) {
                this.incrementErrorCount(); 
            } finally {
                this.incrementTotalCount();
            }
        }

        return null;
    }

    public ArrayList<String> calcTrnc(JexData input, int i2, int i3, int i4) throws JexBIZException 
    {
        ArrayList<String> trucSet = new ArrayList<String>();
        int curDay = StringUtil.toInt(this.curDate.substring(i2, i3));
        int offset = StringUtil.toInt(input.get("OFFSET"));
        if (offset > i4)
        {            
            offset = i4;
        }
        int d = (curDay -offset ) < 0 ? i4 + (curDay - offset) : (curDay - offset);
        if (d == 0)
        {                
            d = i4;
        }
        String dStr = "0" + d;
        trucSet.add(dStr.substring(dStr.length() - 2));

        
        
        
//        // 마지막 일자는 안지워짐
//        for (int i = 0; i < i4 - offset ; i++) 
//        {
//            int d = (curDay - (offset + i) ) < 0 ? i4 + (curDay - (offset + i)) : curDay - (offset + i);
//            if (d == 0)
//            {                
//                d = i4;
//            }
//            String dStr = "0" + d;
//            trucSet.add(dStr.substring(dStr.length() - 2));
//        }
        return trucSet;
    }

    private void executeIdo(String tableExt) throws JexException {

        JexConnection idoCon = JexConnectionManager.createIDOConnection();

        for (int i = 0; i < this.idoList.length; i++) {

            JexDataInIDO jexDataInIDO = (JexDataInIDO) JexDataCreator.fileToJexData(this.getClass(),
                    "IDO." + idoList[i] + ".xml");
            LogIDODataIn logIdoDataIn = getParsedExtIDO(idoList[i], jexDataInIDO, tableExt);

            idoCon.execute(logIdoDataIn);
        }
    }

    protected LogIDODataIn getParsedExtIDO(String id, JexDataInIDO jexData, String extTable) {
        LogIDODataIn logDataInIDO = new LogIDODataIn(id);

        logDataInIDO._setRule(jexData._getRule());
        logDataInIDO._setExtTable("_" + extTable);

        return logDataInIDO;
    }
}
