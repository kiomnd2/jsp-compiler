
package jex.adm.batch.simple.truncate;

import jex.data.impl.ido.JexDataOutIDO;
import jex.data.item.DataItem;
import jex.data.rule.RuleIDO;

public class LogIDODataOut extends JexDataOutIDO 
{
	private static final long serialVersionUID = -6494148039428917677L;
	private DataItem[] _idoItems = null;
	private RuleIDO _idoRule = null;
	
	protected LogIDODataOut(String id, DataItem[] items)
	{
		super(id);
		_idoItems = items;
	}

	@Override
	protected DataItem[] _getDataItems()
	{
		if (_idoItems == null)
		{ 
			_idoItems = _getRule().getOutputDataItems();
		}
		return _idoItems;
	}

	@Override
	public RuleIDO _getRule()
	{
		return _idoRule;
	}
	
	protected void _setRule(RuleIDO idoRule)
	{
		_idoRule = idoRule;
		if (_idoRule != null)
		{
			this._setTarget(_idoRule.getTarget());
		}
	}
}

